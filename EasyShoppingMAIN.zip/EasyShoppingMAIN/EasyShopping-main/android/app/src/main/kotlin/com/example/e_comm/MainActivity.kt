package com.example.e_comm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
